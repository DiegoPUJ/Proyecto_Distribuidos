# http_gateway.py
import uuid
import time

from flask import Flask, request, jsonify
import zmq

from common.enums import Sede, TipoOperacion
from common.messages import SolicitudPS, RespuestaGC
from common.config import get_gc_endpoint_for_sede, REQUEST_TIMEOUT_MS, REQUEST_RETRIES

# Si tienes metrics/collector.py lo podrías usar así:
try:
    from metrics.collector import record_metric  # opcional
except ImportError:
    record_metric = None

app = Flask(__name__)
ctx = zmq.Context.instance()


def enviar_a_gc(tipo_str: str, sede_int: int, codigo_libro: str, usuario_id: str, semanas: int | None):
    # Parsear enums
    tipo = TipoOperacion.from_str(tipo_str)
    sede = Sede.from_int(sede_int)

    endpoint_gc = get_gc_endpoint_for_sede(sede)

    # Crear socket REQ por request (más seguro para muchos requests concurrentes)
    sock = ctx.socket(zmq.REQ)
    sock.RCVTIMEO = REQUEST_TIMEOUT_MS
    sock.SNDTIMEO = REQUEST_TIMEOUT_MS
    sock.connect(endpoint_gc)

    try:
        id_peticion = str(uuid.uuid4())

        solicitud = SolicitudPS.crear_nueva(
            id_peticion=id_peticion,
            tipo=tipo,
            sede=sede,
            codigo_libro=codigo_libro,
            usuario_id=usuario_id,
            semanas=semanas,
        )

        payload = solicitud.to_dict()

        intentos_restantes = REQUEST_RETRIES
        inicio = time.time()

        while intentos_restantes > 0:
            try:
                sock.send_json(payload)
                resp_dict = sock.recv_json()
                dur_ms = (time.time() - inicio) * 1000.0

                respuesta = RespuestaGC.from_dict(resp_dict)

                # Métrica opcional
                if record_metric:
                    record_metric(
                        operacion=tipo.value,
                        sede=sede.value,
                        exito=respuesta.exito,
                        latencia_ms=dur_ms,
                    )

                return respuesta, dur_ms

            except zmq.error.Again:
                intentos_restantes -= 1
                if intentos_restantes == 0:
                    dur_ms = (time.time() - inicio) * 1000.0
                    if record_metric:
                        record_metric(
                            operacion=tipo.value,
                            sede=sede.value,
                            exito=False,
                            latencia_ms=dur_ms,
                        )
                    return None, dur_ms

    finally:
        sock.close(0)


@app.route("/operacion", methods=["POST"])
def operar():
    """
    Espera un JSON tipo:
    {
      "operacion": "PRESTAMO" | "RENOVACION" | "DEVOLUCION",
      "sede": 1 | 2,
      "codigo_libro": "LIB001",
      "usuario_id": "U101",
      "semanas": 2   # opcional
    }
    """
    data = request.get_json(force=True)

    oper_str = data.get("operacion", "")
    sede_int = int(data.get("sede", 0))
    codigo_libro = data.get("codigo_libro")
    usuario_id = data.get("usuario_id")
    semanas = data.get("semanas")

    if not (oper_str and sede_int and codigo_libro and usuario_id):
        return jsonify({"error": "Faltan campos obligatorios"}), 400

    try:
        respuesta, dur_ms = enviar_a_gc(
            tipo_str=oper_str,
            sede_int=sede_int,
            codigo_libro=codigo_libro,
            usuario_id=usuario_id,
            semanas=semanas,
        )
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    if respuesta is None:
        return jsonify({
            "exito": False,
            "mensaje": "Timeout hablando con GC",
            "latencia_ms": dur_ms,
        }), 504

    return jsonify({
        "id_peticion": respuesta.id_peticion,
        "exito": respuesta.exito,
        "mensaje": respuesta.mensaje,
        "datos": respuesta.datos,
        "latencia_ms": dur_ms,
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=False)