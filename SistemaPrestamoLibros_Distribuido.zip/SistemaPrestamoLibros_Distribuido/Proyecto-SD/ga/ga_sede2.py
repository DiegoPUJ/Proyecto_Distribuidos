# ga/ga_sede2.py
import zmq
import threading
from datetime import datetime, timedelta

from common.config import GA_SEDE2_BIND, GA2_REPLICA_PULL
from db.database_sede2 import get_sessionmaker_sede2
from db.models import Libro, InventarioLibroSede, Prestamo


# ============================================================
#  APLICACIÓN DE EVENTOS DE RÉPLICA (GA2 como secundario)
# ============================================================

def aplicar_replica_prestamo(session, ev: dict):
    codigo = ev["codigo_libro"]
    usuario = ev["usuario_id"]
    semanas = ev["semanas"]
    sede = ev["sede"]

    libro = session.query(Libro).filter_by(codigo=codigo).first()
    if not libro:
        return

    inv = (
        session.query(InventarioLibroSede)
        .filter_by(sede_id=sede, libro_id=libro.id)
        .first()
    )
    if not inv:
        return

    if inv.ejemplares_prestados < inv.ejemplares_totales:
        inv.ejemplares_prestados += 1

        p = Prestamo(
            sede_id=sede,
            libro_id=libro.id,
            usuario_id=usuario,
            fecha_prestamo=datetime.utcnow(),
            fecha_entrega=datetime.utcnow() + timedelta(weeks=semanas),
            renovaciones=0,
            devuelto=False,
        )
        session.add(p)

    session.commit()


def aplicar_replica_devolucion(session, ev: dict):
    codigo = ev["codigo_libro"]
    usuario = ev["usuario_id"]
    sede = ev["sede"]

    libro = session.query(Libro).filter_by(codigo=codigo).first()
    if not libro:
        return

    prestamo = (
        session.query(Prestamo)
        .filter_by(
            sede_id=sede,
            libro_id=libro.id,
            usuario_id=usuario,
            devuelto=False,
        )
        .first()
    )
    if not prestamo:
        return

    prestamo.devuelto = True
    prestamo.fecha_devolucion = datetime.utcnow()

    inv = (
        session.query(InventarioLibroSede)
        .filter_by(sede_id=sede, libro_id=libro.id)
        .first()
    )
    if inv and inv.ejemplares_prestados > 0:
        inv.ejemplares_prestados -= 1

    session.commit()


def aplicar_replica_renovacion(session, ev: dict):
    codigo = ev["codigo_libro"]
    usuario = ev["usuario_id"]
    sede = ev["sede"]
    semanas = ev["semanas"]

    libro = session.query(Libro).filter_by(codigo=codigo).first()
    if not libro:
        return

    prestamo = (
        session.query(Prestamo)
        .filter_by(
            sede_id=sede,
            libro_id=libro.id,
            usuario_id=usuario,
            devuelto=False,
        )
        .first()
    )
    if not prestamo:
        return

    prestamo.fecha_entrega += timedelta(weeks=semanas)
    prestamo.renovaciones += 1

    session.commit()


def replica_listener():
    """
    Hilo que corre en GA2 escuchando eventos de réplica enviados por GA1.
    Mientras GA1 está vivo, GA2 se mantiene sincronizado.
    """
    ctx = zmq.Context.instance()
    sock_pull = ctx.socket(zmq.PULL)
    sock_pull.bind(GA2_REPLICA_PULL)
    print(f"[GA Sede2] Escuchando replicación en {GA2_REPLICA_PULL}")

    Session = get_sessionmaker_sede2()

    while True:
        ev = sock_pull.recv_json()
        print(f"[GA Sede2] → Evento replicado recibido: {ev}")

        oper = ev.get("operacion")

        with Session() as session:
            if oper == "PRESTAMO":
                aplicar_replica_prestamo(session, ev)
            elif oper == "DEVOLUCION":
                aplicar_replica_devolucion(session, ev)
            elif oper == "RENOVACION":
                aplicar_replica_renovacion(session, ev)
            else:
                print("[GA Sede2] Operación desconocida en réplica.")


# ============================================================
#  LÓGICA LOCAL (GA2 actuando como primario en failover)
# ============================================================

def procesar_prestamo(session, payload: dict) -> dict:
    id_peticion = payload.get("id_peticion", "")
    codigo_libro = payload.get("codigo_libro")
    usuario_id = payload.get("usuario_id")
    semanas = int(payload.get("semanas") or 2)
    sede_id = int(payload.get("sede") or 1)

    libro = session.query(Libro).filter_by(codigo=codigo_libro).one_or_none()
    if not libro:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": f"Libro {codigo_libro} no existe",
        }

    inv = (
        session.query(InventarioLibroSede)
        .filter_by(sede_id=sede_id, libro_id=libro.id)
        .one_or_none()
    )
    if not inv:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "No hay inventario disponible",
        }

    if inv.ejemplares_prestados >= inv.ejemplares_totales:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "No hay ejemplares disponibles",
        }

    inv.ejemplares_prestados += 1
    ahora = datetime.utcnow()
    fecha_entrega = ahora + timedelta(weeks=semanas)

    p = Prestamo(
        sede_id=sede_id,
        libro_id=libro.id,
        usuario_id=usuario_id,
        fecha_prestamo=ahora,
        fecha_entrega=fecha_entrega,
        renovaciones=0,
        devuelto=False,
    )
    session.add(p)
    session.commit()

    return {
        "id_peticion": id_peticion,
        "aprobado": True,
        "motivo": "Préstamo registrado (GA2 primario)",
        "fecha_entrega": fecha_entrega.isoformat(),
    }


def procesar_devolucion(session, payload: dict) -> dict:
    id_peticion = payload.get("id_peticion", "")
    codigo_libro = payload.get("codigo_libro")
    usuario_id = payload.get("usuario_id")
    sede = int(payload.get("sede") or 1)

    libro = session.query(Libro).filter_by(codigo=codigo_libro).one_or_none()
    if not libro:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "Libro no existe",
        }

    prestamo = (
        session.query(Prestamo)
        .filter_by(
            sede_id=sede,
            libro_id=libro.id,
            usuario_id=usuario_id,
            devuelto=False,
        )
        .first()
    )
    if not prestamo:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "No existe préstamo activo",
        }

    prestamo.devuelto = True
    prestamo.fecha_devolucion = datetime.utcnow()

    inv = (
        session.query(InventarioLibroSede)
        .filter_by(sede_id=sede, libro_id=libro.id)
        .first()
    )
    if inv and inv.ejemplares_prestados > 0:
        inv.ejemplares_prestados -= 1

    session.commit()

    return {
        "id_peticion": id_peticion,
        "aprobado": True,
        "motivo": "Devolución registrada (GA2 primario)",
    }


def procesar_renovacion(session, payload: dict) -> dict:
    id_peticion = payload.get("id_peticion", "")
    codigo_libro = payload.get("codigo_libro")
    usuario_id = payload.get("usuario_id")
    semanas = int(payload.get("semanas") or 1)
    sede = int(payload.get("sede") or 1)

    libro = session.query(Libro).filter_by(codigo=codigo_libro).one_or_none()
    if not libro:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "Libro no existe",
        }

    prestamo = (
        session.query(Prestamo)
        .filter_by(
            sede_id=sede,
            libro_id=libro.id,
            usuario_id=usuario_id,
            devuelto=False,
        )
        .first()
    )

    if not prestamo:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "No existe préstamo activo",
        }

    prestamo.fecha_entrega += timedelta(weeks=semanas)
    prestamo.renovaciones += 1
    session.commit()

    return {
        "id_peticion": id_peticion,
        "aprobado": True,
        "motivo": "Renovación registrada (GA2 primario)",
        "nueva_fecha_entrega": prestamo.fecha_entrega.isoformat(),
    }


# ============================================================
#  LOOP PRINCIPAL - GA2 COMO SERVICIO
# ============================================================

def main():
    ctx = zmq.Context.instance()

    # Hilo de réplica GA1 → GA2 (mantiene BD2 actualizada mientras GA1 vive)
    thread_replica = threading.Thread(target=replica_listener, daemon=True)
    thread_replica.start()

    # Socket REP para actores (en failover, los actores apuntan aquí)
    sock_rep = ctx.socket(zmq.REP)
    sock_rep.bind(GA_SEDE2_BIND)
    print(f"[GA Sede2] Escuchando actores en {GA_SEDE2_BIND}")

    Session = get_sessionmaker_sede2()

    try:
        while True:
            payload = sock_rep.recv_json()
            oper = payload.get("operacion", "").upper()
            print(f"[GA Sede2] Solicitud recibida: {payload}")

            with Session() as session:
                if oper == "PRESTAMO":
                    resp = procesar_prestamo(session, payload)
                elif oper == "DEVOLUCION":
                    resp = procesar_devolucion(session, payload)
                elif oper == "RENOVACION":
                    resp = procesar_renovacion(session, payload)
                else:
                    resp = {
                        "id_peticion": payload.get("id_peticion", ""),
                        "aprobado": False,
                        "motivo": f"Operación '{oper}' no reconocida en GA2",
                    }

            sock_rep.send_json(resp)

    except KeyboardInterrupt:
        print("[GA Sede2] Cerrando...")

    finally:
        sock_rep.close(0)
        ctx.term()


if __name__ == "_main_":
    main()