# ga/ga_sede1.py
import zmq
from datetime import datetime, timedelta

from common.config import GA_SEDE1_BIND, GA1_REPLICA_PUSH
from db.database import get_sessionmaker_sede1
from db.models import Libro, InventarioLibroSede, Prestamo


def procesar_prestamo(session, payload: dict, sock_push_replica) -> dict:
    id_peticion = payload.get("id_peticion", "")
    codigo_libro = payload.get("codigo_libro")
    usuario_id = payload.get("usuario_id")
    semanas = int(payload.get("semanas") or 2)
    sede_id = int(payload.get("sede") or 1)

    libro = session.query(Libro).filter_by(codigo=codigo_libro).one_or_none()
    if not libro:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": f"Libro {codigo_libro} no existe",
        }

    inv = (
        session.query(InventarioLibroSede)
        .filter_by(sede_id=sede_id, libro_id=libro.id)
        .one_or_none()
    )
    if not inv:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "No hay inventario disponible",
        }

    if inv.ejemplares_prestados >= inv.ejemplares_totales:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "No hay ejemplares disponibles",
        }

    inv.ejemplares_prestados += 1
    ahora = datetime.utcnow()
    fecha_entrega = ahora + timedelta(weeks=semanas)

    p = Prestamo(
        sede_id=sede_id,
        libro_id=libro.id,
        usuario_id=usuario_id,
        fecha_prestamo=ahora,
        fecha_entrega=fecha_entrega,
        renovaciones=0,
        devuelto=False,
    )
    session.add(p)
    session.commit()

    # Evento para replicar a GA2
    evento = {
        "operacion": "PRESTAMO",
        "sede": sede_id,
        "codigo_libro": codigo_libro,
        "usuario_id": usuario_id,
        "semanas": semanas,
    }
    sock_push_replica.send_json(evento)

    return {
        "id_peticion": id_peticion,
        "aprobado": True,
        "motivo": "Préstamo registrado",
        "fecha_entrega": fecha_entrega.isoformat(),
    }


def procesar_devolucion(session, payload: dict, sock_push_replica) -> dict:
    id_peticion = payload.get("id_peticion", "")
    codigo_libro = payload.get("codigo_libro")
    usuario_id = payload.get("usuario_id")
    sede = int(payload.get("sede") or 1)

    libro = session.query(Libro).filter_by(codigo=codigo_libro).one_or_none()
    if not libro:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "Libro no existe",
        }

    prestamo = (
        session.query(Prestamo)
        .filter_by(sede_id=sede, libro_id=libro.id, usuario_id=usuario_id, devuelto=False)
        .first()
    )
    if not prestamo:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "No existe préstamo activo",
        }

    prestamo.devuelto = True
    prestamo.fecha_devolucion = datetime.utcnow()

    inv = (
        session.query(InventarioLibroSede)
        .filter_by(sede_id=sede, libro_id=libro.id)
        .first()
    )
    if inv.ejemplares_prestados > 0:
        inv.ejemplares_prestados -= 1

    session.commit()

    evento = {
        "operacion": "DEVOLUCION",
        "sede": sede,
        "codigo_libro": codigo_libro,
        "usuario_id": usuario_id,
    }
    sock_push_replica.send_json(evento)

    return {
        "id_peticion": id_peticion,
        "aprobado": True,
        "motivo": "Devolución registrada",
    }


def procesar_renovacion(session, payload: dict, sock_push_replica) -> dict:
    id_peticion = payload.get("id_peticion", "")
    codigo_libro = payload.get("codigo_libro")
    usuario_id = payload.get("usuario_id")
    semanas = int(payload.get("semanas") or 1)
    sede = int(payload.get("sede") or 1)

    libro = session.query(Libro).filter_by(codigo=codigo_libro).one_or_none()
    if not libro:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "Libro no existe",
        }

    prestamo = (
        session.query(Prestamo)
        .filter_by(sede_id=sede, libro_id=libro.id, usuario_id=usuario_id, devuelto=False)
        .first()
    )

    if not prestamo:
        return {
            "id_peticion": id_peticion,
            "aprobado": False,
            "motivo": "No existe préstamo activo",
        }

    prestamo.fecha_entrega += timedelta(weeks=semanas)
    prestamo.renovaciones += 1
    session.commit()

    evento = {
        "operacion": "RENOVACION",
        "sede": sede,
        "codigo_libro": codigo_libro,
        "usuario_id": usuario_id,
        "semanas": semanas,
    }
    sock_push_replica.send_json(evento)

    return {
        "id_peticion": id_peticion,
        "aprobado": True,
        "motivo": "Renovación registrada",
        "nueva_fecha_entrega": prestamo.fecha_entrega.isoformat(),
    }


def main():
    ctx = zmq.Context.instance()

    # GA1 atiende actores (REQ/REP)
    sock_rep = ctx.socket(zmq.REP)
    sock_rep.bind(GA_SEDE1_BIND)
    print(f"[GA Sede1] Escuchando actores en {GA_SEDE1_BIND}")

    # GA1 envía eventos de réplica hacia GA2 (PUSH)
    sock_push_replica = ctx.socket(zmq.PUSH)
    sock_push_replica.connect(GA1_REPLICA_PUSH)
    print(f"[GA Sede1] Replicación hacia GA2 conectada en {GA1_REPLICA_PUSH}")

    Session = get_sessionmaker_sede1()

    try:
        while True:
            payload = sock_rep.recv_json()
            oper = payload.get("operacion", "").upper()

            with Session() as session:
                if oper == "PRESTAMO":
                    resp = procesar_prestamo(session, payload, sock_push_replica)
                elif oper == "DEVOLUCION":
                    resp = procesar_devolucion(session, payload, sock_push_replica)
                elif oper == "RENOVACION":
                    resp = procesar_renovacion(session, payload, sock_push_replica)
                else:
                    resp = {"error": "Operacion no reconocida"}

            sock_rep.send_json(resp)

    except KeyboardInterrupt:
        print("[GA Sede1] Cerrando...")

    finally:
        sock_rep.close(0)
        sock_push_replica.close(0)
        ctx.term()


if __name__ == "__main__":
    main()
