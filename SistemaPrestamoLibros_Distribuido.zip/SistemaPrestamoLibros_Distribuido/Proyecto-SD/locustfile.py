# locustfile.py
import random
from locust import HttpUser, task, between


CODIGOS_LIBRO = [f"LIB{i:03d}" for i in range(1, 200)]  # rango razonable
USUARIOS = [f"U{u}" for u in range(100, 200)]


class BibliotecaUser(HttpUser):
    # Espera entre 0.1 y 1s entre requests (lo puedes tunear)
    wait_time = between(0.1, 1.0)

    # host lo defines al lanzar locust: --host=http://192.168.1.65:8000

    def _random_payload(self, operacion: str):
        sede = random.choice([1, 2])
        codigo = random.choice(CODIGOS_LIBRO)
        usuario = random.choice(USUARIOS)

        payload = {
            "operacion": operacion,
            "sede": sede,
            "codigo_libro": codigo,
            "usuario_id": usuario,
        }

        if operacion in ("PRESTAMO", "RENOVACION"):
            payload["semanas"] = random.choice([1, 2, 3])

        return payload

    @task(5)
    def prestamo(self):
        payload = self._random_payload("PRESTAMO")
        self.client.post("/operacion", json=payload)

    @task(3)
    def renovacion(self):
        payload = self._random_payload("RENOVACION")
        self.client.post("/operacion", json=payload)

    @task(2)
    def devolucion(self):
        payload = self._random_payload("DEVOLUCION")
        self.client.post("/operacion", json=payload)