# gc/gc_sede2.py
import json
import zmq

from common.config import (
    GC_SEDE2_BIND,
    GC_SEDE2_PUB_BIND,
    ACTOR_PRESTAMO_SEDE2_ENDPOINT,
)
from common.enums import TipoOperacion


def main():
    ctx = zmq.Context.instance()

    # ============================
    # PS → GC Sede 2  (síncrono REP)
    # ============================
    sock_rep = ctx.socket(zmq.REP)
    sock_rep.bind(GC_SEDE2_BIND)
    print(f"[GC Sede2] Escuchando PS en {GC_SEDE2_BIND}")

    # ============================
    # GC Sede 2 → Actores (PUB)
    # Para DEVOLUCION y RENOVACION
    # ============================
    sock_pub = ctx.socket(zmq.PUB)
    sock_pub.bind(GC_SEDE2_PUB_BIND)
    print(f"[GC Sede2] Publicando a actores en {GC_SEDE2_PUB_BIND}")

    # ============================
    # GC Sede 2 → ActorPréstamo Sede 2 (REQ → REP)
    # ============================
    sock_req_actor_prestamo = ctx.socket(zmq.REQ)
    sock_req_actor_prestamo.connect(ACTOR_PRESTAMO_SEDE2_ENDPOINT)
    print(
        f"[GC Sede2] Conectado a ActorPréstamo en "
        f"{ACTOR_PRESTAMO_SEDE2_ENDPOINT}"
    )

    try:
        while True:
            msg = sock_rep.recv_json()
            print(f"\n[GC Sede2] Recibido de PS: {msg}")

            tipo_str = msg.get("tipo", "").upper()
            id_peticion = msg.get("id_peticion", "")
            sede = msg.get("sede")

            # Validar tipo de operación
            try:
                tipo = TipoOperacion.from_str(tipo_str)
            except ValueError:
                print(f"[GC Sede2] ERROR tipo operación inválido: {tipo_str}")
                respuesta = {
                    "id_peticion": id_peticion,
                    "exito": False,
                    "mensaje": f"Tipo de operación inválido: {tipo_str}",
                    "datos": None,
                }
                sock_rep.send_json(respuesta)
                continue

            # ======================================
            #  DEVOLUCION / RENOVACION → ASÍNCRONO
            # ======================================
            if tipo in (TipoOperacion.DEVOLUCION, TipoOperacion.RENOVACION):
                # 1) Responder rápido al PS
                respuesta = {
                    "id_peticion": id_peticion,
                    "exito": True,
                    "mensaje": f"{tipo.value} aceptada en GC Sede 2",
                    "datos": {"sede": sede},
                }
                sock_rep.send_json(respuesta)

                # 2) Publicar al tópico correspondiente
                topic = tipo.value  # "DEVOLUCION" o "RENOVACION"
                payload = json.dumps(msg).encode("utf-8")
                sock_pub.send_multipart([topic.encode("utf-8"), payload])

                print(f"[GC Sede2] Publicado en tópico '{topic}': {msg}")
                continue

            # ======================================
            #  PRESTAMO → SINCRONO
            # ======================================
            if tipo == TipoOperacion.PRESTAMO:
                try:
                    # Flujo: PS → GC2 → ActorPréstamo S2 → GC2 → PS
                    sock_req_actor_prestamo.send_json(msg)
                    resp_actor = sock_req_actor_prestamo.recv_json()
                    print(f"[GC Sede2] Respuesta actor préstamo: {resp_actor}")

                    aprobado = bool(resp_actor.get("aprobado", False))
                    motivo = resp_actor.get("motivo", "")

                    respuesta = {
                        "id_peticion": id_peticion,
                        "exito": aprobado,
                        "mensaje": motivo,
                        "datos": resp_actor,
                    }
                    sock_rep.send_json(respuesta)

                except zmq.ZMQError as e:
                    print(f"[GC Sede2] ERROR hablando con ActorPréstamo: {e}")
                    respuesta = {
                        "id_peticion": id_peticion,
                        "exito": False,
                        "mensaje": "Error interno al procesar el préstamo",
                        "datos": None,
                    }
                    sock_rep.send_json(respuesta)

                continue

            # ======================================
            # Cualquier otra operación no soportada
            # ======================================
            respuesta = {
                "id_peticion": id_peticion,
                "exito": False,
                "mensaje": f"Operación no soportada: {tipo.value}",
                "datos": None,
            }
            sock_rep.send_json(respuesta)

    except KeyboardInterrupt:
        print("\n[GC Sede2] Cerrando...")

    finally:
        sock_rep.close(0)
        sock_pub.close(0)
        sock_req_actor_prestamo.close(0)
        ctx.term()


if __name__ == "__main__":
    main()