# gc/gc_sede1.py
import json
import zmq

from common.config import (
    GC_SEDE1_BIND,
    GC_SEDE1_PUB_BIND,
    ACTOR_PRESTAMO_SEDE1_ENDPOINT,
)
from common.enums import TipoOperacion


def main():
    ctx = zmq.Context.instance()

    # ============================
    # PS → GC  (síncrono REP)
    # ============================
    sock_rep = ctx.socket(zmq.REP)
    sock_rep.bind(GC_SEDE1_BIND)
    print(f"[GC Sede1] Escuchando PS en {GC_SEDE1_BIND}")

    # ============================
    # GC → Actores (PUB para DEVOLUCION / RENOVACION)
    # ============================
    sock_pub = ctx.socket(zmq.PUB)
    sock_pub.bind(GC_SEDE1_PUB_BIND)
    print(f"[GC Sede1] Publicando a actores en {GC_SEDE1_PUB_BIND}")

    # ============================
    # GC → ActorPréstamo (REQ → REP)
    # ============================
    sock_req_actor_prestamo = ctx.socket(zmq.REQ)
    sock_req_actor_prestamo.connect(ACTOR_PRESTAMO_SEDE1_ENDPOINT)
    print(f"[GC Sede1] Conectado a ActorPréstamo en {ACTOR_PRESTAMO_SEDE1_ENDPOINT}")

    try:
        while True:
            msg = sock_rep.recv_json()
            print(f"\n[GC Sede1] Recibido de PS: {msg}")

            tipo_str = msg.get("tipo", "").upper()
            id_peticion = msg.get("id_peticion", "")
            sede = msg.get("sede")

            # Validar tipo de operación
            try:
                tipo = TipoOperacion.from_str(tipo_str)
            except ValueError:
                print(f"[GC Sede1] ERROR tipo operación inválido: {tipo_str}")
                sock_rep.send_json({
                    "id_peticion": id_peticion,
                    "exito": False,
                    "mensaje": f"Tipo de operación inválido: {tipo_str}",
                    "datos": None,
                })
                continue

            # ======================================
            # 🎯 DEVOLUCION o RENOVACION → ASÍNCRONO
            # ======================================
            if tipo in (TipoOperacion.DEVOLUCION, TipoOperacion.RENOVACION):

                # 1) Respuesta instantánea al PS
                sock_rep.send_json({
                    "id_peticion": id_peticion,
                    "exito": True,
                    "mensaje": f"{tipo.value} aceptada en GC Sede 1",
                    "datos": {"sede": sede},
                })

                # 2) Publicar a actores
                topic = tipo.value
                payload = json.dumps(msg).encode("utf-8")
                sock_pub.send_multipart([topic.encode("utf-8"), payload])

                print(f"[GC Sede1] Publicado en tópico '{topic}': {msg}")
                continue

            # ======================================
            # 🎯 PRESTAMO → SINCRONO
            # ======================================
            if tipo == TipoOperacion.PRESTAMO:
                try:
                    sock_req_actor_prestamo.send_json(msg)
                    resp_actor = sock_req_actor_prestamo.recv_json()
                    print(f"[GC Sede1] Respuesta de ActorPréstamo: {resp_actor}")

                    aprobado = bool(resp_actor.get("aprobado", False))
                    motivo = resp_actor.get("motivo", "")

                    sock_rep.send_json({
                        "id_peticion": id_peticion,
                        "exito": aprobado,
                        "mensaje": motivo,
                        "datos": resp_actor,
                    })

                except zmq.ZMQError as e:
                    print(f"[GC Sede1] ERROR con ActorPréstamo: {e}")
                    sock_rep.send_json({
                        "id_peticion": id_peticion,
                        "exito": False,
                        "mensaje": "Error interno al procesar el préstamo",
                        "datos": None,
                    })

                continue

            # ======================================
            # Si llega algo raro (no debería)
            # ======================================
            sock_rep.send_json({
                "id_peticion": id_peticion,
                "exito": False,
                "mensaje": f"Operación no soportada: {tipo.value}",
                "datos": None,
            })

    except KeyboardInterrupt:
        print("\n[GC Sede1] Cerrando...")

    finally:
        sock_rep.close()
        sock_pub.close()
        sock_req_actor_prestamo.close()
        ctx.term()


if __name__ == "__main__":
    main()