import json
import zmq

from common.config import GC_SEDE1_PUB_ENDPOINT, GA_SEDE1_ENDPOINT


TOPIC = "DEVOLUCION"


def main():
    ctx = zmq.Context.instance()

    # SUB al PUB del GC Sede 1 (en tu máquina 192.168.1.65)
    sock_sub = ctx.socket(zmq.SUB)
    sock_sub.connect(GC_SEDE1_PUB_ENDPOINT)
    sock_sub.setsockopt_string(zmq.SUBSCRIBE, TOPIC)

    # REQ hacia GA Sede 1 (máquina 2)
    sock_req_ga = ctx.socket(zmq.REQ)
    sock_req_ga.connect(GA_SEDE1_ENDPOINT)

    print(f"[ActorDevolucion Sede1] Conectado a PUB {GC_SEDE1_PUB_ENDPOINT}")
    print(f"[ActorDevolucion Sede1] Suscrito al tópico '{TOPIC}'")
    print(f"[ActorDevolucion Sede1] Conectado a GA Sede1 en {GA_SEDE1_ENDPOINT}")

    try:
        while True:
            topic_bytes, payload_bytes = sock_sub.recv_multipart()
            topic = topic_bytes.decode("utf-8")
            payload_str = payload_bytes.decode("utf-8")

            try:
                msg = json.loads(payload_str)
            except json.JSONDecodeError:
                print(f"[ActorDevolucion Sede1] ERROR parseando JSON: {payload_str}")
                continue

            print(f"\n[ActorDevolucion Sede1] Mensaje en tópico '{topic}': {msg}")

            payload_ga = {
                "operacion": "DEVOLUCION",
                "id_peticion": msg.get("id_peticion", ""),
                "codigo_libro": msg.get("codigo_libro", ""),
                "usuario_id": msg.get("usuario_id", ""),
                "sede": msg.get("sede", 1),
            }

            # Llamar a GA Sede 1
            sock_req_ga.send_json(payload_ga)
            respuesta_ga = sock_req_ga.recv_json()

            print(f"[ActorDevolucion Sede1] Respuesta GA: {respuesta_ga}")

    except KeyboardInterrupt:
        print("\n[ActorDevolucion Sede1] Cerrando...")

    finally:
        sock_req_ga.close(0)
        sock_sub.close(0)
        ctx.term()


if __name__ == "__main__":
    main()