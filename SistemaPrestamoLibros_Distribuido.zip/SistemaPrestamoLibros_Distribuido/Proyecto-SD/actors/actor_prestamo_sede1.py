import zmq

from common.config import ACTOR_PRESTAMO_SEDE1_ENDPOINT, GA_SEDE1_ENDPOINT


def main():
    ctx = zmq.Context.instance()

    # Actor escucha al GC (REQ de GC → REP de actor)
    sock_rep_gc = ctx.socket(zmq.REP)

    # En config: ACTOR_PRESTAMO_SEDE1_ENDPOINT = "tcp://127.0.0.1:5571"
    # Reemplazamos 127.0.0.1 por * para escuchar en todas las interfaces
    bind_endpoint = ACTOR_PRESTAMO_SEDE1_ENDPOINT.replace("127.0.0.1", "*")
    sock_rep_gc.bind(bind_endpoint)
    print(f"[ActorPréstamo Sede1] Escuchando GC en {bind_endpoint}")

    # Actor se conecta al GA Sede 1 (que está en la máquina 2)
    sock_req_ga = ctx.socket(zmq.REQ)
    sock_req_ga.connect(GA_SEDE1_ENDPOINT)
    print(f"[ActorPréstamo Sede1] Conectado a GA Sede1 en {GA_SEDE1_ENDPOINT}")

    try:
        while True:
            solicitud = sock_rep_gc.recv_json()
            print(f"\n[ActorPréstamo Sede1] Solicitud recibida desde GC: {solicitud}")

            id_peticion = solicitud.get("id_peticion", "")
            codigo_libro = solicitud.get("codigo_libro", "")
            usuario_id = solicitud.get("usuario_id", "")
            semanas = solicitud.get("semanas") or 2
            sede = solicitud.get("sede") or 1

            # Payload para GA
            payload_ga = {
                "operacion": "PRESTAMO",
                "id_peticion": id_peticion,
                "codigo_libro": codigo_libro,
                "usuario_id": usuario_id,
                "semanas": semanas,
                "sede": sede,
            }

            # Llamar a GA Sede 1
            sock_req_ga.send_json(payload_ga)
            respuesta_ga = sock_req_ga.recv_json()

            print(f"[ActorPréstamo Sede1] Respuesta desde GA: {respuesta_ga}")

            # Respuesta al GC
            respuesta_gc = {
                "id_peticion": respuesta_ga.get("id_peticion", id_peticion),
                "aprobado": respuesta_ga.get("aprobado", False),
                "motivo": respuesta_ga.get("motivo", ""),
                "fecha_entrega": respuesta_ga.get("fecha_entrega"),
                "codigo_libro": codigo_libro,
                "usuario_id": usuario_id,
            }

            sock_rep_gc.send_json(respuesta_gc)

    except KeyboardInterrupt:
        print("\n[ActorPréstamo Sede1] Cerrando...")

    finally:
        sock_req_ga.close(0)
        sock_rep_gc.close(0)
        ctx.term()


if __name__ == "__main__":
    main()