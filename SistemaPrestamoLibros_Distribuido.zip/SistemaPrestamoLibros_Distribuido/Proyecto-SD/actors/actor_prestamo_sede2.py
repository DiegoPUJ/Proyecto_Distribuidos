import zmq

from common.config import ACTOR_PRESTAMO_SEDE2_ENDPOINT, GA_SEDE1_ENDPOINT


def main():
    ctx = zmq.Context.instance()

    # Actor escucha al GC Sede 2 (REQ → REP)
    sock_rep_gc = ctx.socket(zmq.REP)

    # En config: "tcp://10.43.102.23:5661"
    # REEMPLAZAMOS la IP por * para escuchar en todas las interfaces
    bind_endpoint = ACTOR_PRESTAMO_SEDE2_ENDPOINT.replace("10.43.102.23", "*")
    sock_rep_gc.bind(bind_endpoint)

    print(f"[ActorPréstamo Sede2] Escuchando GC 2 en {bind_endpoint}")

    # Actor se conecta al GA Sede 1 (ojo: YA NO GA2)
    sock_req_ga = ctx.socket(zmq.REQ)
    sock_req_ga.connect(GA_SEDE1_ENDPOINT)

    print(f"[ActorPréstamo Sede2] Conectado a GA Sede1 en {GA_SEDE1_ENDPOINT}")

    try:
        while True:
            solicitud = sock_rep_gc.recv_json()
            print(f"\n[ActorPréstamo Sede2] Solicitud desde GC: {solicitud}")

            id_peticion = solicitud.get("id_peticion", "")
            codigo_libro = solicitud.get("codigo_libro", "")
            usuario_id = solicitud.get("usuario_id", "")
            semanas = solicitud.get("semanas", 2)
            sede = solicitud.get("sede", 2)

            payload_ga = {
                "operacion": "PRESTAMO",
                "id_peticion": id_peticion,
                "codigo_libro": codigo_libro,
                "usuario_id": usuario_id,
                "semanas": semanas,
                "sede": sede,
            }

            # Mandamos el préstamo a GA1
            sock_req_ga.send_json(payload_ga)
            respuesta_ga = sock_req_ga.recv_json()

            print(f"[ActorPréstamo Sede2] Respuesta GA1: {respuesta_ga}")

            respuesta_gc = {
                "id_peticion": respuesta_ga.get("id_peticion", id_peticion),
                "aprobado": respuesta_ga.get("aprobado", False),
                "motivo": respuesta_ga.get("motivo", ""),
                "fecha_entrega": respuesta_ga.get("fecha_entrega"),
                "codigo_libro": codigo_libro,
                "usuario_id": usuario_id,
            }

            sock_rep_gc.send_json(respuesta_gc)

    except KeyboardInterrupt:
        print("\n[ActorPréstamo Sede2] Cerrando...")

    finally:
        sock_req_ga.close()
        sock_rep_gc.close()
        ctx.term()


if __name__ == "__main__":
    main()
