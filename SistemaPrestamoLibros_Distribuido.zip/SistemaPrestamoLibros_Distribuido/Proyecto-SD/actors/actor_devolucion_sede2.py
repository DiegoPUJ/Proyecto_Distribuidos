import json
import zmq

from common.config import GC_SEDE2_PUB_ENDPOINT, GA_SEDE1_ENDPOINT

TOPIC = "DEVOLUCION"


def main():
    ctx = zmq.Context.instance()

    # SUB al PUB del GC Sede 2
    sock_sub = ctx.socket(zmq.SUB)
    sock_sub.connect(GC_SEDE2_PUB_ENDPOINT)
    sock_sub.setsockopt_string(zmq.SUBSCRIBE, TOPIC)

    # REQ hacia GA Sede 1 (NO GA2)
    sock_req_ga = ctx.socket(zmq.REQ)
    sock_req_ga.connect(GA_SEDE1_ENDPOINT)

    print(f"[ActorDevolucion Sede2] Conectado a PUB {GC_SEDE2_PUB_ENDPOINT}")
    print(f"[ActorDevolucion Sede2] Suscrito al tópico '{TOPIC}'")
    print(f"[ActorDevolucion Sede2] Conectado a GA Sede1 en {GA_SEDE1_ENDPOINT}")

    try:
        while True:
            topic_bytes, payload_bytes = sock_sub.recv_multipart()
            payload_str = payload_bytes.decode("utf-8")

            try:
                msg = json.loads(payload_str)
            except json.JSONDecodeError:
                print(f"[ActorDevolucion Sede2] ERROR JSON: {payload_str}")
                continue

            print(f"\n[ActorDevolucion Sede2] Mensaje SUB: {msg}")

            payload_ga = {
                "operacion": "DEVOLUCION",
                "id_peticion": msg.get("id_peticion", ""),
                "codigo_libro": msg.get("codigo_libro", ""),
                "usuario_id": msg.get("usuario_id", ""),
                "sede": msg.get("sede", 2),  # importante mantener sede 2
            }

            # Enviamos la operación a GA1
            sock_req_ga.send_json(payload_ga)
            respuesta_ga = sock_req_ga.recv_json()

            print(f"[ActorDevolucion Sede2] Respuesta GA1: {respuesta_ga}")

    except KeyboardInterrupt:
        print("\n[ActorDevolucion Sede2] Cerrando...")

    finally:
        sock_req_ga.close()
        sock_sub.close()
        ctx.term()


if __name__ == "__main__":
    main()
