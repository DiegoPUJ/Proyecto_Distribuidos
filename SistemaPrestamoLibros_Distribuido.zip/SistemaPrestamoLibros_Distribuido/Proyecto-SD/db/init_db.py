# db/init_db.py  (Sede 1)
import random
from datetime import datetime, timedelta

from .database import create_all_sede1, get_sessionmaker_sede1
from .models import SedeDB, Libro, InventarioLibroSede, Prestamo


def poblar_datos_iniciales(session):
    # ===========================
    # CREAR SEDES
    # ===========================
    sede1 = SedeDB(nombre="Sede 1")
    sede2 = SedeDB(nombre="Sede 2")
    session.add_all([sede1, sede2])
    session.flush()    # genera IDs

    # ===========================
    # CREAR 1000 LIBROS
    # ===========================
    libros = []
    for i in range(1, 1001):
        libro = Libro(
            codigo=f"LIB{i:03d}",
            titulo=f"Libro {i:03d}",
            autor=f"Autor {random.randint(1, 200)}",
            categoria=random.choice(["Ciencia", "Historia", "Novela", "Tecnología"])
        )
        libros.append(libro)

    session.add_all(libros)
    session.flush()

    # ===========================
    # CREAR INVENTARIO POR SEDE
    # ===========================
    inventarios = []
    for libro in libros:
        total = random.randint(1, 5)

        inventarios.append(
            InventarioLibroSede(
                sede_id=sede1.id,
                libro_id=libro.id,
                ejemplares_totales=total,
                ejemplares_prestados=0
            )
        )
        inventarios.append(
            InventarioLibroSede(
                sede_id=sede2.id,
                libro_id=libro.id,
                ejemplares_totales=total,
                ejemplares_prestados=0
            )
        )

    session.add_all(inventarios)
    session.flush()

    # Diccionario auxiliar para préstamos
    inv_por_sede_libro = {(inv.sede_id, inv.libro_id): inv for inv in inventarios}

    # ===========================
    # PRÉSTAMOS INICIALES
    # ===========================
    prestamos = []
    ahora = datetime.utcnow()

    # 150 en sede 1
    for libro in random.sample(libros, 150):
        inv = inv_por_sede_libro[(sede1.id, libro.id)]
        if inv.ejemplares_prestados < inv.ejemplares_totales:
            inv.ejemplares_prestados += 1
            prestamos.append(
                Prestamo(
                    sede_id=sede1.id,
                    libro_id=libro.id,
                    usuario_id=f"U{random.randint(100,999)}",
                    fecha_prestamo=ahora - timedelta(days=random.randint(0,7)),
                    fecha_entrega=ahora + timedelta(days=7),
                    renovaciones=0,
                    devuelto=False
                )
            )

    # 50 en sede 2
    for libro in random.sample(libros, 50):
        inv = inv_por_sede_libro[(sede2.id, libro.id)]
        if inv.ejemplares_prestados < inv.ejemplares_totales:
            inv.ejemplares_prestados += 1
            prestamos.append(
                Prestamo(
                    sede_id=sede2.id,
                    libro_id=libro.id,
                    usuario_id=f"U{random.randint(100,999)}",
                    fecha_prestamo=ahora - timedelta(days=random.randint(0,7)),
                    fecha_entrega=ahora + timedelta(days=7),
                    renovaciones=0,
                    devuelto=False
                )
            )

    session.add_all(prestamos)
    session.commit()

    print("Sede 1 poblada correctamente.")


def main():
    create_all_sede1()
    Session = get_sessionmaker_sede1()
    with Session() as session:
        poblar_datos_iniciales(session)


if __name__ == "__main__":
    main()
