# db/models.py
from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    ForeignKey,
    UniqueConstraint,
    Boolean,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class SedeDB(Base):
    __tablename__ = "sede"

    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String(50), unique=True, nullable=False)

    inventarios = relationship("InventarioLibroSede", back_populates="sede")
    prestamos = relationship("Prestamo", back_populates="sede")


class Libro(Base):
    __tablename__ = "libro"

    id = Column(Integer, primary_key=True, autoincrement=True)
    codigo = Column(String(50), unique=True, nullable=False)
    titulo = Column(String(255), nullable=False)
    autor = Column(String(255), nullable=True)
    categoria = Column(String(100), nullable=True)

    inventarios = relationship("InventarioLibroSede", back_populates="libro")
    prestamos = relationship("Prestamo", back_populates="libro")


class InventarioLibroSede(Base):
    __tablename__ = "inventario_libro_sede"

    id = Column(Integer, primary_key=True, autoincrement=True)
    sede_id = Column(Integer, ForeignKey("sede.id"), nullable=False)
    libro_id = Column(Integer, ForeignKey("libro.id"), nullable=False)

    ejemplares_totales = Column(Integer, nullable=False, default=1)
    ejemplares_prestados = Column(Integer, nullable=False, default=0)

    __table_args__ = (
        UniqueConstraint("sede_id", "libro_id", name="uq_sede_libro"),
    )

    sede = relationship("SedeDB", back_populates="inventarios")
    libro = relationship("Libro", back_populates="inventarios")


class Prestamo(Base):
    __tablename__ = "prestamo"

    id = Column(Integer, primary_key=True, autoincrement=True)
    sede_id = Column(Integer, ForeignKey("sede.id"), nullable=False)
    libro_id = Column(Integer, ForeignKey("libro.id"), nullable=False)
    usuario_id = Column(String(50), nullable=False)

    fecha_prestamo = Column(DateTime, default=datetime.utcnow, nullable=False)
    fecha_entrega = Column(DateTime, nullable=False)
    renovaciones = Column(Integer, nullable=False, default=0)

    # para devoluciones/renovaciones reales
    devuelto = Column(Boolean, nullable=False, default=False)
    fecha_devolucion = Column(DateTime, nullable=True)

    sede = relationship("SedeDB", back_populates="prestamos")
    libro = relationship("Libro", back_populates="prestamos")
