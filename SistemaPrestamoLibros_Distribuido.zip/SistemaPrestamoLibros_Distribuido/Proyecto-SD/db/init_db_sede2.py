# db/init_db_sede2.py
import random
from datetime import datetime, timedelta

from .database_sede2 import create_all_sede2, get_sessionmaker_sede2
from .models import SedeDB, Libro, InventarioLibroSede, Prestamo


def poblar_datos_iniciales(session):
    # ===========================
    # CREAR SEDES
    # ===========================
    sede1 = SedeDB(nombre="Sede 1")
    sede2 = SedeDB(nombre="Sede 2")
    session.add_all([sede1, sede2])
    session.flush()

    # ===========================
    # CREAR 1000 LIBROS
    # ===========================
    libros = []
    for i in range(1, 1001):
        libro = Libro(
            codigo=f"LIB{i:03d}",
            titulo=f"Libro {i:03d}",
            autor=f"Autor {random.randint(1, 200)}",
            categoria=random.choice(["Ciencia", "Historia", "Novela", "Tecnología"])
        )
        libros.append(libro)

    session.add_all(libros)
    session.flush()

    # ===========================
    # INVENTARIO PARA AMBAS SEDES
    # ===========================
    inventarios = []
    for libro in libros:
        total = random.randint(1, 5)

        inventarios.append(
            InventarioLibroSede(
                sede_id=sede1.id,
                libro_id=libro.id,
                ejemplares_totales=total,
                ejemplares_prestados=0
            )
        )
        inventarios.append(
            InventarioLibroSede(
                sede_id=sede2.id,
                libro_id=libro.id,
                ejemplares_totales=total,
                ejemplares_prestados=0
            )
        )

    session.add_all(inventarios)
    session.flush()

    inv_por_sede_libro = {(inv.sede_id, inv.libro_id): inv for inv in inventarios}

    # ===========================
    # PRÉSTAMOS INICIALES
    # ===========================
    ahora = datetime.utcnow()
    prestamos = []

    # 150 sede 1
    for libro in random.sample(libros, 150):
        inv = inv_por_sede_libro[(sede1.id, libro.id)]
        if inv.ejemplares_prestados < inv.ejemplares_totales:
            inv.ejemplares_prestados += 1
            prestamos.append(
                Prestamo(
                    sede_id=sede1.id,
                    libro_id=libro.id,
                    usuario_id=f"U{random.randint(100,999)}",
                    fecha_prestamo=ahora,
                    fecha_entrega=ahora + timedelta(days=7),
                    renovaciones=0,
                    devuelto=False
                )
            )

    # 50 sede 2
    for libro in random.sample(libros, 50):
        inv = inv_por_sede_libro[(sede2.id, libro.id)]
        if inv.ejemplares_prestados < inv.ejemplares_totales:
            inv.ejemplares_prestados += 1
            prestamos.append(
                Prestamo(
                    sede_id=sede2.id,
                    libro_id=libro.id,
                    usuario_id=f"U{random.randint(100,999)}",
                    fecha_prestamo=ahora,
                    fecha_entrega=ahora + timedelta(days=7),
                    renovaciones=0,
                    devuelto=False
                )
            )

    session.add_all(prestamos)
    session.commit()

    print("Sede 2 poblada correctamente.")


def main():
    create_all_sede2()
    Session = get_sessionmaker_sede2()
    with Session() as session:
        poblar_datos_iniciales(session)


if __name__ == "__main__":
    main()
