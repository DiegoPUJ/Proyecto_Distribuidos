# db/database_sede2.py
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .models import Base

# BD local en la máquina donde corre GA Sede 2 (10.43.102.23)
DATABASE_URL_SEDE2 = os.getenv(
    "DATABASE_URL_SEDE2",
    "sqlite:///biblioteca_sede2.db",   # Local a GA Sede 2
)

def get_engine_sede2():
    engine = create_engine(
        DATABASE_URL_SEDE2,
        echo=False,
        future=True,
        connect_args={"check_same_thread": False}  # Para uso multihilo (PULL replicación + REP)
    )
    return engine

def get_sessionmaker_sede2():
    engine = get_engine_sede2()
    SessionLocal = sessionmaker(
        bind=engine,
        autoflush=False,
        autocommit=False,
    )
    return SessionLocal

def create_all_sede2():
    engine = get_engine_sede2()
    Base.metadata.create_all(bind=engine)
