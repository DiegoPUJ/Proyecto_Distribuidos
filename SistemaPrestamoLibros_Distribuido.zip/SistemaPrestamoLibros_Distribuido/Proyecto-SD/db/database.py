# db/database.py
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .models import Base

# BD local en la máquina donde corre GA Sede 1 (10.43.102.221)
DATABASE_URL_SEDE1 = os.getenv(
    "DATABASE_URL_SEDE1",
    "sqlite:///biblioteca_sede1.db",   # Local a GA Sede 1
)

def get_engine_sede1():
    engine = create_engine(
        DATABASE_URL_SEDE1,
        echo=False,
        future=True,
        connect_args={"check_same_thread": False}  # IMPORTANTE para hilos / ZMQ
    )
    return engine

def get_sessionmaker_sede1():
    engine = get_engine_sede1()
    SessionLocal = sessionmaker(
        bind=engine,
        autoflush=False,
        autocommit=False,
    )
    return SessionLocal

def create_all_sede1():
    engine = get_engine_sede1()
    Base.metadata.create_all(bind=engine)
