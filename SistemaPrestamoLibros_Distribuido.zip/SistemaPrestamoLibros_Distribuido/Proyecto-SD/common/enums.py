from enum import Enum


class Sede(Enum):
    SEDE_1 = 1
    SEDE_2 = 2

    @staticmethod
    def from_int(value: int) -> "Sede":
        if value == 1:
            return Sede.SEDE_1
        elif value == 2:
            return Sede.SEDE_2
        else:
            raise ValueError(f"Sede inválida: {value}")


class TipoOperacion(Enum):
    PRESTAMO = "PRESTAMO"
    RENOVACION = "RENOVACION"
    DEVOLUCION = "DEVOLUCION"

    @staticmethod
    def from_str(value: str) -> "TipoOperacion":
        upper = value.strip().upper()
        try:
            return TipoOperacion(upper)
        except ValueError:
            raise ValueError(f"Operación inválida: {value}")