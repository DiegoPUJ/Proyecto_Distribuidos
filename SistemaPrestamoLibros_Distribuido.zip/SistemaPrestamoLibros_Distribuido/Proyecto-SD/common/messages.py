from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Optional, Any, Dict

from .enums import TipoOperacion, Sede


@dataclass
class SolicitudPS:
    id_peticion: str
    tipo: TipoOperacion
    sede: Sede
    codigo_libro: str
    usuario_id: str
    semanas: Optional[int] = None
    timestamp_iso: str = ""

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["tipo"] = self.tipo.value
        d["sede"] = self.sede.value  # 1 o 2
        return d

    @staticmethod
    def crear_nueva(
        id_peticion: str,
        tipo: TipoOperacion,
        sede: Sede,
        codigo_libro: str,
        usuario_id: str,
        semanas: Optional[int],
    ) -> "SolicitudPS":
        return SolicitudPS(
            id_peticion=id_peticion,
            tipo=tipo,
            sede=sede,
            codigo_libro=codigo_libro,
            usuario_id=usuario_id,
            semanas=semanas,
            timestamp_iso=datetime.utcnow().isoformat(),
        )


@dataclass
class RespuestaGC:
    id_peticion: str
    exito: bool
    mensaje: str
    datos: Optional[Dict[str, Any]] = None

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "RespuestaGC":
        return RespuestaGC(
            id_peticion=data.get("id_peticion", ""),
            exito=bool(data.get("exito", False)),
            mensaje=data.get("mensaje", ""),
            datos=data.get("datos"),
        )