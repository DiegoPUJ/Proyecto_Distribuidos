# common/config.py  (MÁQUINA 1 y 3 - PS, GC, actores, GA2)
import os
from .enums import Sede

# ================================================================
# FLAG DE FAILOVER
# ================================================================
# Cuando MODO_FAILOVER = False → actores hablan con GA1 (normal)
# Cuando MODO_FAILOVER = True  → actores hablan con GA2 (GA1 caído)
MODO_FAILOVER = True  # <-- CAMBIA ESTO A True PARA EL ESCENARIO DE FAILOVER


# ================================================================
#                  💻  MÁQUINA 1 — SEDE 1
#         IP: 192.168.1.65  (Windows)
#         Corre: PS, GC Sede 1, Actores Sede 1
# ================================================================

GC_SEDE1_ENDPOINT = "tcp://192.168.1.65:5551"   # PS → GC S1
GC_SEDE1_BIND     = "tcp://*:5551"

GC_SEDE1_PUB_ENDPOINT = "tcp://192.168.1.65:5561"
GC_SEDE1_PUB_BIND     = "tcp://*:5561"

ACTOR_PRESTAMO_SEDE1_ENDPOINT   = "tcp://127.0.0.1:5571"
ACTOR_DEVOLUCION_SEDE1_ENDPOINT = "tcp://127.0.0.1:5572"
ACTOR_RENOVACION_SEDE1_ENDPOINT = "tcp://127.0.0.1:5573"


# ================================================================
#             💻  MÁQUINA 2 — GA SEDE 1 + BD SEDE1
#          IP: 10.43.102.221
# ================================================================

GA_SEDE1_BIND = "tcp://*:5581"  # Solo lo usa la máquina 2

# Según el modo, actores se conectan a GA1 o GA2
if not MODO_FAILOVER:
    # Modo normal: actores → GA1
    GA_SEDE1_ENDPOINT = "tcp://10.43.102.221:5581"
else:
    # Modo failover: actores → GA2 (máquina 3)
    GA_SEDE1_ENDPOINT = "tcp://10.43.102.23:5582"


# ================================================================
#     💻  MÁQUINA 3 — SEDE 2 COMPLETA (GA2, GC2, Actores2, BD2)
#          IP: 10.43.102.23
# ================================================================

GC_SEDE2_ENDPOINT = "tcp://10.43.102.23:5651"
GC_SEDE2_BIND     = "tcp://*:5651"

GC_SEDE2_PUB_ENDPOINT = "tcp://10.43.102.23:5652"
GC_SEDE2_PUB_BIND     = "tcp://*:5652"

ACTOR_PRESTAMO_SEDE2_ENDPOINT   = "tcp://10.43.102.23:5661"
ACTOR_DEVOLUCION_SEDE2_ENDPOINT = "tcp://10.43.102.23:5662"
ACTOR_RENOVACION_SEDE2_ENDPOINT = "tcp://10.43.102.23:5663"

GA_SEDE2_ENDPOINT = "tcp://10.43.102.23:5582"
GA_SEDE2_BIND     = "tcp://*:5582"


# ================================================================
#                 🎓 REPLICACIÓN GA1 → GA2
# ================================================================

GA1_REPLICA_PUSH = "tcp://10.43.102.23:5591"   # GA1 → CONNECT a GA2
GA2_REPLICA_PULL = "tcp://*:5591"              # GA2 → BIND (PULL)


# ================================================================
#                   ⚙️ CONFIG PS (cliente)
# ================================================================
REQUEST_TIMEOUT_MS = int(os.getenv("PS_REQUEST_TIMEOUT_MS", "5000"))
REQUEST_RETRIES    = int(os.getenv("PS_REQUEST_RETRIES", "3"))


# ================================================================
# Helper para PS: escoger GC correcto según sede
# ================================================================
def get_gc_endpoint_for_sede(sede: Sede) -> str:
    if sede == Sede.SEDE_1:
        return GC_SEDE1_ENDPOINT
    elif sede == Sede.SEDE_2:
        return GC_SEDE2_ENDPOINT
    else:
        raise ValueError(f"Sede no soportada: {sede}")
