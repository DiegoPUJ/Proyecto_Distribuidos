# Sistema Distribuido de Préstamo de Libros — Proyecto SD (Python + ZeroMQ)

Este proyecto implementa un sistema distribuido completo para gestionar **préstamos**, **renovaciones** y **devoluciones** de libros en dos sedes distintas, siguiendo exactamente los lineamientos del curso de **Sistemas Distribuidos**.

El sistema está diseñado para ejecutarse en **tres máquinas** y soporta:
- Comunicación síncrona y asíncrona.
- Múltiples procesos distribuidos (PS, GC, Actores, GA).
- Uso obligatorio de **ZeroMQ**.
- Manejo de **fallas** de la BD primaria y conmutación hacia la réplica.
- Toma de **métricas de rendimiento** para la segunda entrega.
- Ejecución en **dos sedes independientes**, cada una con su propio GC + Actores.

---

# 📁 Estructura del Proyecto

```
biblioteca-distribuida/
  common/
    config.py
    enums.py
    messages.py

  ps/
    ps_client.py

  gc/
    gc_sede1.py
    gc_sede2.py   (pendiente)

  actors/
    actor_prestamo_sede1.py
    actor_devolucion_sede1.py   (pendiente)
    actor_renovacion_sede1.py   (pendiente)

    actor_prestamo_sede2.py     (pendiente)
    actor_devolucion_sede2.py   (pendiente)
    actor_renovacion_sede2.py   (pendiente)

  ga/
    ga_sede1.py   (pendiente — BD primaria)
    ga_sede2.py   (pendiente — Réplica)

  db/
    models.py
    init_db.py

  metrics/
    collector.py

  operaciones/
    sede1/
      operaciones_sede1.csv
    sede2/
      operaciones_sede2.csv

  README.md
  requirements.txt
```

---

# 🧱 Componentes Principales

### ✅ **PS (Proceso Solicitante)**
- Único proceso capaz de realizar:
  - PRESTAMO
  - RENOVACION
  - DEVOLUCION
- Lee operaciones desde archivos CSV.
- Se conecta por **REQ/REP** con el GC de cada sede.
- Maneja timeouts y reintentos.

---

### ✅ **GC (Gestor de Carga)**
Cada sede tiene uno.

**Funciones:**
- Recibe operaciones desde PS usando REP.
- Para DEVOLUCION y RENOVACION:
  - responde inmediatamente al PS
  - publica el mensaje en un tópico PUB/SUB
- Para PRESTAMO:
  - envía la solicitud al actor de préstamo por REQ
  - espera la respuesta
  - devuelve el resultado al PS

**Sockets:**
- REP: PS → GC
- PUB: GC → Actores de Devolución/Renovación
- REQ: GC → ActorPréstamo

---

### ✅ **Actores**
Tres por sede:

#### 🔵 Actor de Préstamo
- Recibe solicitudes síncronas desde el GC.
- Consulta el GA (más adelante).
- Devuelve aprobación o rechazo.

#### 🟢 Actor de Devolución (PUB/SUB)
- Recibe mensajes publicados desde el GC.
- Actualiza BD -> GA.

#### 🟠 Actor de Renovación (PUB/SUB)
- Igual que el de devolución.

---

### 🗄️ **GA — Gestor de Almacenamiento**
Cada sede tiene uno:

- `ga_sede1.py` → BD primaria
- `ga_sede2.py` → BD réplica

El GA:
- Recibe peticiones desde actores.
- Realiza operaciones CRUD en BD.
- Replica cambios hacia la BD secundaria **asíncronamente**.
- Ante falla de la BD primaria → redirige hacia la réplica automáticamente.

---

### 🛢️ **BD (MySQL o PostgreSQL)**
- 1000 libros iniciales.
- 150 prestados en sede 1.
- 50 prestados en sede 2.
- `init_db.py` generará datos automáticos.

---

### 📊 **Metrics**
- Mide:
  - Tiempo de respuesta promedio
  - Desviación estándar
  - Solicitudes procesadas por minuto
- Puede exportar a CSV.

---

# ⚙️ Patrones de Comunicación ZeroMQ

| Módulo | Patrón | Descripción |
|-------|--------|-------------|
| PS → GC | REQ/REP | comunicación síncrona |
| GC → Actores (Renovación/Devolución) | PUB/SUB | comunicación asíncrona |
| GC → Actor Préstamo | REQ/REP | comunicación síncrona |
| Actores → GA | REQ/REP | síncrono para consulta BD |
| GA1 → GA2 | Asíncrono simulado | replicación |

---

# 🧪 Repositorio de pruebas (operaciones por sede)

```
operaciones/
  sede1/
    operaciones_sede1.csv
  sede2/
    operaciones_sede2.csv
```

Cada archivo tendrá **mínimo 20 operaciones**.

---

# 🖥️ Ejecución del Sistema

### 1. Instalar entorno
```
python -m venv venv
venv\Scripts\activate  # Windows
pip install -r requirements.txt
```

### 2. Levantar Actor de Préstamo
```
python -m actors.actor_prestamo_sede1
```

### 3. Levantar Gestor de Carga
```
python -m gc.gc_sede1
```

### 4. Ejecutar PS
```
python -m ps.ps_client --archivo operaciones/sede1/operaciones_sede1.csv
```

---

# 📌 Próximos pasos del proyecto (roadmap)

### 🔜 Entorno básico (lo actual)
- [x] PS completo
- [x] Common (config, mensajes, enums)
- [x] GC sede 1
- [x] Actor Préstamo sede 1
- [ ] Carpeta `operaciones/sede1` + `operaciones/sede2`

### 🔜 Siguiente fase
- [ ] Actor Renovación sede 1
- [ ] Actor Devolución sede 1
- [ ] GC sede 2
- [ ] Actores sede 2

### 🔜 Fase GA + BD
- [ ] GA sede 1 (primaria)
- [ ] GA sede 2 (réplica)
- [ ] Replicación asíncrona
- [ ] Manejo de fallas

### 🔜 Fase de Rendimiento
- [ ] Medición de tiempo de respuesta
- [ ] Gráficas
- [ ] Comparación de escenario A o B

---

# ✔️ Con esto el proyecto queda **totalmente organizado** y listo para avanzar.
