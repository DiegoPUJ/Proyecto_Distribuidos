# ps/ps.py
import argparse
import csv
import time
import uuid

import zmq

from common.enums import Sede, TipoOperacion
from common.messages import SolicitudPS, RespuestaGC
from common.config import (
    get_gc_endpoint_for_sede,
    REQUEST_TIMEOUT_MS,
    REQUEST_RETRIES,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Proceso Solicitante (PS) - Biblioteca distribuida"
    )
    parser.add_argument(
        "--archivo",
        required=True,
        help="Ruta al archivo CSV con las operaciones a enviar",
    )
    parser.add_argument(
        "--delay-ms",
        type=int,
        default=0,
        help="Delay entre operaciones (en milisegundos)",
    )
    return parser.parse_args()


def leer_operaciones_desde_csv(path: str):
    """
    Espera un CSV con columnas:
    operacion,sede,codigo_libro,usuario_id,semanas
    """
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            oper_str = row["operacion"]
            sede_int = int(row["sede"])
            codigo_libro = row["codigo_libro"]
            usuario_id = row["usuario_id"]
            semanas_str = row.get("semanas") or ""

            tipo = TipoOperacion.from_str(oper_str)
            sede = Sede.from_int(sede_int)
            semanas = int(semanas_str) if semanas_str.strip() else None

            yield tipo, sede, codigo_libro, usuario_id, semanas


def main():
    args = parse_args()
    contexto = zmq.Context.instance()

    print(f"[PS] Leyendo operaciones desde: {args.archivo}")
    if args.delay_ms > 0:
        print(f"[PS] Delay entre operaciones: {args.delay_ms} ms")
    print(f"[PS] TIMEOUT={REQUEST_TIMEOUT_MS} ms | RETRIES={REQUEST_RETRIES}")

    # Mapeo sede -> socket REQ
    sockets_por_sede: dict[Sede, zmq.Socket] = {}

    try:
        for (
            tipo,
            sede,
            codigo_libro,
            usuario_id,
            semanas,
        ) in leer_operaciones_desde_csv(args.archivo):

            # Crear/conectar socket para esa sede si no existe
            if sede not in sockets_por_sede:
                endpoint = get_gc_endpoint_for_sede(sede)
                sock = contexto.socket(zmq.REQ)
                sock.connect(endpoint)
                sock.RCVTIMEO = REQUEST_TIMEOUT_MS
                sock.SNDTIMEO = REQUEST_TIMEOUT_MS
                sockets_por_sede[sede] = sock
                print(f"[PS] Conectado a GC de {sede.name} en {endpoint}")

            socket = sockets_por_sede[sede]

            # Crear mensaje
            id_peticion = str(uuid.uuid4())
            solicitud = SolicitudPS.crear_nueva(
                id_peticion=id_peticion,
                tipo=tipo,
                sede=sede,
                codigo_libro=codigo_libro,
                usuario_id=usuario_id,
                semanas=semanas,
            )

            payload = solicitud.to_dict()
            print(f"\n[PS] Enviando solicitud {id_peticion}: {payload}")

            # Intentos de reintento básicos
            intentos_restantes = REQUEST_RETRIES
            while intentos_restantes > 0:
                try:
                    socket.send_json(payload)
                    resp_dict = socket.recv_json()
                    respuesta = RespuestaGC.from_dict(resp_dict)

                    estado = "OK" if respuesta.exito else "FALLÓ"
                    print(
                        f"[PS] Respuesta {respuesta.id_peticion}: "
                        f"{estado} - {respuesta.mensaje} | datos={respuesta.datos}"
                    )
                    break  # salió bien

                except zmq.error.Again:
                    intentos_restantes -= 1
                    print(
                        f"[PS] Time-out esperando respuesta de GC {sede.name}. "
                        f"Reintentos restantes: {intentos_restantes}"
                    )
                    if intentos_restantes == 0:
                        print(
                            f"[PS] ERROR: No se obtuvo respuesta del GC de {sede.name} "
                            f"para la petición {id_peticion}"
                        )
                        break

            # Delay entre operaciones si se pidió
            if args.delay_ms > 0:
                time.sleep(args.delay_ms / 1000.0)

    finally:
        # Cerrar sockets
        for sock in sockets_por_sede.values():
            sock.close(0)
        contexto.term()


if __name__ == "__main__":
    main()
